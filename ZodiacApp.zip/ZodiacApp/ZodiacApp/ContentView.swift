import SwiftUI

struct ContentView: View {

    let animalNames = ["RAT", "OX", "TIGER", "RABBIT", "DRAGON", "SNAKE", "HORSE", "GOAT", "MONKEY", "ROOSTER", "DOG", "PIG"]
    
    let animalImages = ["RAT", "OX", "TIGER", "RABBIT", "DRAGON", "SNAKE", "HORSE", "GOAT", "MONKEY", "ROOSTER", "DOG", "PIG"]
    
    @State private var currentYear = 2023
    
    let yearFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .none
        return formatter
    }()

    var body: some View {
        VStack {

            Text("\(yearFormatter.string(from: NSNumber(value: currentYear)) ?? "\(currentYear)")")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.red)
                .padding()

            let currentIndex = (currentYear - 2023 + 3 + 12) % 12

            Image(animalImages[currentIndex])
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 400)
            

            Text(animalNames[currentIndex])
                .font(.largeTitle)
                .fontWeight(.black)
                .padding()

            HStack {

                Button(action: {
                    currentYear -= 1
                }) {
                    Text("<")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                        .padding()
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.red, lineWidth: 3)
                        )
                }
                .frame(width: 60, height: 60)

                Spacer()

                Button(action: {
                    currentYear += 1
                }) {
                    Text(">")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                        .padding()
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.red, lineWidth: 3)
                        )
                }
                .frame(width: 60, height: 60)
            }
            .padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

